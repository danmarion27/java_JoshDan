package car.adapter;

public interface Car {

    public void accelerate();
    public void insertFuel();

}
