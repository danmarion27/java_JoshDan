package car.adapter;

public interface ToyCar {


    // Target interface
    //ToyCars can't fill gas, they accelerate

    public void accelerates();

}
